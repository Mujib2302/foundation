/*
  Applies the photos listed in assets/site-images.js to the page.

  You should not need to edit this file to change a photo — edit
  assets/site-images.js instead. This file only needs to change if a
  brand-new kind of image slot is being added (not just a new photo for
  one that already exists).

  Every element this script touches keeps its original src/background as a
  plain HTML attribute, so if this script ever fails to load (or SITE_IMAGES
  is missing an entry), the page still shows a real photo instead of a
  broken image — it just won't reflect the latest edit to site-images.js.
*/
(function () {
  if (typeof SITE_IMAGES === 'undefined') return;

  // Simple photo swaps: any element marked data-img-key="some.key" gets its
  // src (for <img>) or background-image (for anything else) set from
  // SITE_IMAGES["some.key"], if that key exists.
  document.querySelectorAll('[data-img-key]').forEach(function (el) {
    var key = el.getAttribute('data-img-key');
    var src = SITE_IMAGES[key];
    if (!src) return;
    if (el.tagName === 'IMG') {
      el.src = src;
    } else {
      el.style.backgroundImage = "url('" + src + "')";
    }
  });

  // Homepage hero banner: rebuilt from SITE_IMAGES["hero.slides"] so that
  // adding/removing a slide is only ever a change to that one list. The
  // slideshow's own script (further down the page) reads whatever slide/dot
  // elements exist at the time it runs, so as long as this script runs
  // first, the slideshow always picks up the current slide list — timing,
  // fade and zoom motion are controlled by CSS/JS elsewhere and never change
  // no matter how many slides are listed.
  var heroTrack = document.querySelector('.hero-slideshow');
  var dotsTrack = document.querySelector('.hero-slide-dots');
  var slides = SITE_IMAGES['hero.slides'];
  if (heroTrack && dotsTrack && Array.isArray(slides) && slides.length) {
    heroTrack.innerHTML = '';
    dotsTrack.innerHTML = '';
    slides.forEach(function (src, i) {
      var slide = document.createElement('div');
      slide.className = 'slide' + (i === 0 ? ' active' : '');
      slide.style.backgroundImage = "url('" + src + "')";
      heroTrack.appendChild(slide);

      var dot = document.createElement('span');
      dot.className = 'dot' + (i === 0 ? ' active' : '');
      dot.addEventListener('click', function () { setHeroSlide(i); });
      dotsTrack.appendChild(dot);
    });
  }
})();
