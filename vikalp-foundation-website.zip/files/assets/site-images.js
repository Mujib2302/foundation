/*
  ============================================================
  VIKALP FOUNDATION — SITE IMAGES
  ============================================================
  This is the ONLY file you need to touch to change a photo
  anywhere on the site.

  HOW TO CHANGE A PHOTO
  1. Find the line below for the photo you want to change
     (the comments tell you where each one is used).
  2. Replace the text in quotes with the new image's path.
       - A local file:           "images/my-new-photo.jpg"
       - A web address:          "https://example.com/photo.jpg"
  3. Save this file and refresh the page in your browser.
  No other file needs to change, and this same photo updates
  everywhere it's used (e.g. the founder photo appears on both
  the homepage and the About Us page from this one entry).

  HERO BANNER (homepage rotating background)
  This one is a list, not a single photo, because the banner
  cycles through all of them. To add a new slide, add a new
  line inside the brackets. To remove one, delete its line. The
  speed, fade, and zoom motion never change — that's controlled
  elsewhere and always stays the same no matter how many slides
  are listed here.
  ============================================================
*/
const SITE_IMAGES = {

  // Header logo (shown wherever the site uses the real logo image)
  "logo": "images/vikalp_logo.png",

  // Homepage hero banner — rotates every 1.5 seconds, in this order.
  // Add or remove lines to add/remove a slide.
  "hero.slides": [
    "images/user_bg_1.jpeg",
    "images/user_bg_2.jpeg",
    "images/user_bg_4.jpeg",
    "images/user_bg_5.jpeg"
  ],

  // Founder & Director photo — homepage "About" section + About Us page
  "founder.photo": "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80",

  // Same photo, smaller crop, used in the "Vikalp in the News" clipping
  // (homepage + News page). Change independently if you want a different
  // photo there than the one used for the founder profile.
  "news.founder-photo": "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80",

  // "Three Core Pillars" photos — homepage + Program Areas page
  "pillar.environment": "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=800&q=80",
  "pillar.climate": "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=800&q=80",
  "pillar.skilling": "https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&w=800&q=80",

  // "Our Initiatives" program photos — homepage + Our Initiatives page
  // (in the same order the cards appear on the page)
  "initiative.women-sewing": "https://images.unsplash.com/photo-1596464716127-f2a82984de30?auto=format&fit=crop&w=600&q=80",
  "initiative.safai-saathi-children": "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=600&q=80",
  "initiative.paper-bags": "https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=600&q=80",
  "initiative.footwear-ongc": "https://images.unsplash.com/photo-1511556532299-8f662fc26c06?auto=format&fit=crop&w=600&q=80",
  "initiative.zerotrash-tumbler": "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=600&q=80",
  "initiative.covid-relief": "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=600&q=80",
  "initiative.bidar-council": "https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&w=600&q=80",
  "initiative.womens-day": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80",
  "initiative.beach-cleanup": "https://images.unsplash.com/photo-1618477388954-7852f32655ec?auto=format&fit=crop&w=600&q=80",
  "initiative.alibaug-iec": "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=600&q=80",
  "initiative.plastic-quiz": "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=600&q=80",

  // Partner logos — homepage + Partners page (same order as they appear)
  "partner.unltd-india": "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=300&q=80",
  "partner.ongc": "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=300&q=80",
  "partner.godrej": "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?auto=format&fit=crop&w=300&q=80",
  "partner.bidar-city-council": "https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=300&q=80",
  "partner.tetra-pak": "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=300&q=80",
  "partner.greensole": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=300&q=80",
  "partner.zerotrash": "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=300&q=80",
  "partner.sampurn-earth": "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=300&q=80",
  "partner.alibaug-parishad": "https://images.unsplash.com/photo-1582562124811-c09040d0a901?auto=format&fit=crop&w=300&q=80"
};
